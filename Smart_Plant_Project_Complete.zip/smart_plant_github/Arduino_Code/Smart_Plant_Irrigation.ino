/*
  Project: Smart Plant Monitoring and Irrigation System
  Controller: Arduino UNO
  Soil moisture sensor: Analog output -> A0
  Relay module input: D8

  IMPORTANT:
  - This sketch controls local automatic irrigation.
  - It does NOT implement Wi-Fi/IoT communication.
  - Confirm your sensor's dry/wet readings before using it.
  - Many relay modules are active-LOW. Change the values below
    if your relay module uses the opposite logic.
*/

const int soilMoisturePin = A0;
const int relayPin = 8;

// Calibrate these values using your own sensor.
// This example uses hysteresis to reduce rapid relay switching.
const int LOW_LEVEL = 300;
const int HIGH_LEVEL = 600;

// Most common relay modules are active LOW.
const int RELAY_ON = LOW;
const int RELAY_OFF = HIGH;

bool pumpOn = false;

void setup() {
  Serial.begin(9600);

  pinMode(soilMoisturePin, INPUT);
  pinMode(relayPin, OUTPUT);

  // Keep the pump OFF when the system starts.
  digitalWrite(relayPin, RELAY_OFF);

  Serial.println("Smart Plant Monitoring and Irrigation System");
  Serial.println("System started.");
}

void loop() {
  int moistureValue = analogRead(soilMoisturePin);

  Serial.print("Soil moisture value: ");
  Serial.println(moistureValue);

  /*
    Example threshold behaviour:
    - Above HIGH_LEVEL: treat as dry and turn pump ON.
    - Below LOW_LEVEL: treat as sufficiently moist and turn pump OFF.
    - Between thresholds: keep the previous pump state.

    If your sensor gives lower readings when dry, reverse this
    comparison after checking readings in dry and wet soil.
  */
  if (moistureValue > HIGH_LEVEL && !pumpOn) {
    pumpOn = true;
    digitalWrite(relayPin, RELAY_ON);
    Serial.println("Soil is dry - Pump ON");
  }
  else if (moistureValue < LOW_LEVEL && pumpOn) {
    pumpOn = false;
    digitalWrite(relayPin, RELAY_OFF);
    Serial.println("Soil is sufficiently moist - Pump OFF");
  }
  else {
    Serial.println(pumpOn ? "Pump status: ON" : "Pump status: OFF");
  }

  delay(2000);
}

const int soilSensor = A0;
const int relayPin = 8;

int soilValue = 0;

// Soil moisture thresholds
const int DRY_VALUE = 600;
const int WET_VALUE = 400;

bool pumpOn = false;

void setup() {
  Serial.begin(9600);

  pinMode(soilSensor, INPUT);
  pinMode(relayPin, OUTPUT);

  // Relay OFF initially (Active LOW)
  digitalWrite(relayPin, HIGH);
}

void loop() {

  // Read soil moisture sensor
  soilValue = analogRead(soilSensor);

  Serial.print("Soil Moisture Value: ");
  Serial.println(soilValue);

  // If soil is dry, turn pump ON
  if (soilValue > DRY_VALUE && !pumpOn) {
    digitalWrite(relayPin, LOW);
    pumpOn = true;
    Serial.println("Soil is DRY - Pump ON");
  }

  // If soil is wet, turn pump OFF
  else if (soilValue < WET_VALUE && pumpOn) {
    digitalWrite(relayPin, HIGH);
    pumpOn = false;
    Serial.println("Soil is WET - Pump OFF");
  }

  delay(1000);
}
